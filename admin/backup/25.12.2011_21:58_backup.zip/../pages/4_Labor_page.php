<article>
      <header>
        <time datetime="2011-04-13" pubdate>13.April 2011</time>
        <h1>Generator-Download</h1>
      </header>

        <p>Generator in various versions:</p>

      <ul>
	<li><a href="<?php echo BASE ?>/tmp/generator-0.3.1.zip">Version 0.3.1</a> · Extra für DrJack. 894,5 kB (gepackt 545,8 kB) </li>
	<li><a href="<?php echo BASE ?>/tmp/generator-0.2.tar">Version 0.2</a> · Seitenverwaltung (create, edit, delete) inkl. Icons umgesetzt.</li>
	<li><a href="<?php echo BASE ?>/tmp/generator-0.1.tar">Version 0.1</a> · erste Version</li>
      </ul>
</article>
