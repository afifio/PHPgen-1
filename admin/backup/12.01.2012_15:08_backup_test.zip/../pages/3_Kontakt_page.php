<?php 
error_reporting(E_ALL ^ E_NOTICE); // hide all basic notices from PHP

session_start();
$sessionstringnew = null;
$sessionstringadd = null;
if (!isset($_COOKIE[session_name()])) {
    $sessionstringnew = '?' . session_name() . "=" . session_id();
    $sessionstringadd = '&amp;' . session_name() . "=" . session_id();
}

$valid = sha1(trim(strip_tags(strtoupper($_POST['code']))));
$revalid = $_SESSION['P91Captcha_code'];

$r1 = array("Ä","ä","Ü","ü","Ö","ö","ß","@","€","\$","’");
$r2 = array("Ae","ae","Ue","ue;","Oe","oe","ss","[at]","Euro","Dollar","'"); // Simple by vaddi

//If the form is submitted
if(isset($_POST['submitted'])) {
	
	// captcha 
	if (empty($_POST['code'])) {
		$captchaError = 'Sie haben kein Captcha eingegeben.';
		$hasError = true;
	} else if (sha1(trim(strip_tags(strtoupper($_POST['code'])))) != $_SESSION['P91Captcha_code']) {
		$captchaError = 'Das Captcha ist falsch, bitte nochmal!';
		$hasError = true;
	}

	// require a name from user
	if(trim($_POST['contactName']) === '') {
		$nameError =  'Bitte geben Sie einen Namen ein!'; 
		$hasError = true;
	} else {
		$name = trim($_POST['contactName']);
		$name = str_replace($r1, $r2, $name);
		$name = str_replace('[^\w\s[:punct:]]*', ' ', $name);

	}
	
	// need valid email
	if(trim($_POST['email']) === '')  {
		$emailError = 'Bitte geben Sie eine g&uuml;ltige email Adresse ein.';
		$hasError = true;
	} else if (!preg_match("/^[[:alnum:]][a-z0-9_.-]*@[a-z0-9.-]+\.[a-z]{2,4}$/i", trim($_POST['email']))) {
		$emailError = 'Sie haben keine g&uuml;ltige email Adresse eingegeben.';
		$hasError = true;
	} else {
		$email = trim($_POST['email']);
	}
		
	// we need at least some content
	if(trim($_POST['comments']) === '') {
		$commentError = 'Bitte geben Sie eine Nachrich an uns ein!';
		$hasError = true;
	} else {
		if(function_exists('stripslashes')) {
			$comments = stripslashes(trim($_POST['comments']));
			//$comments = stripslashes(trim(strip_tags($_POST['comments'])));
			$comments = str_replace($r1, $r2, $comments);
			$comments = str_replace('[^\w\s[:punct:]]*', ' ', $comments);
		} else {
			$comments = trim($_POST['comments']);
		}
	}
		
	// upon no failure errors let's email now!
	if(!isset($hasError)) {
			$ip = $_SERVER['REMOTE_ADDR'];
			$host = gethostbyaddr($ip);
			$timestamp = time ();
			$datum = date ("d.m.Y", $timestamp);
			$uhrzeit = date ("H:i:s", $timestamp);
		$emailTo = 'kontakt@exigem.com';
		$subject = 'Webformular Nachricht von '.$name;
		$sendCopy = trim($_POST['sendCopy']);
		$body = "
Eine neue Nachricht wurde &uuml;ber das Webformular (http://www.exigem.com/contact/) von: $name ($email) abgesendet. 
--------------------------------------------------------------------------------------------------------------

$comments

--------------------------------------------------------------------------------------------------------------
IP: $ip
Host: $host
Gesendet am $datum um $uhrzeit.
--------------------------------------------------------------------------------------------------------------";
//		$headers = 'From: ' .' <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;
		$headers = 'From: ' .$name.' <'.$emailTo.'>';

		mail($emailTo, $subject, $body, $headers);
        
        // set our boolean completion value to TRUE
		$emailSent = true;
	}
}

?>

<script type="text/javascript">
function P91Captcha(sid){
	var pas = new Image();
	var heuri = new Date();
	pas.src="inc/captcha_form.php?x="+heuri.getTime()+sid;
	document.getElementById("P91Captcha").src=pas.src;
}
</script>

<article>
  <header>
    <time datetime="2011-11-11" pubdate>11.November 2011</time>
    <h1>Kontaktformular</h1>
  </header>

    <!-- @begin contact -->
    <div id="contact" class="section">
      <div class="container content">
		
	<?php if(isset($emailSent) && $emailSent == true) { ?>
	  <meta http-equiv="refresh" content="2; url=./index.php" />
          <p class="info">Ihre Nachricht wurde zugestellt.</p>
        <?php } else { ?>
	  <div class="desc">
	    <p class="desc">Bitte geben Sie Ihre Daten in die vorgesehenen Felder ein und klicken anschlie&szlig;end auf Absenden. Es ist notwendig eine gültige E-Mail Adresse f&uuml;r R&uuml;ckfragen mit anzugeben, alternativ k&ouml;nnen Sie uns auch klassisch per E-Mail (<a href="mailto:info&#64;exigem&#46;com">info&#64;exigem&#46;com</a>) eine Nachricht zukommen lassen. </p>
	  </div>
				
	  <div id="contact-form">
	    <?php if(isset($hasError) || isset($captchaError) ) { ?>
<!--          <p class="alert">Error submitting the form</p> -->
            <?php } ?>
				
	    <form id="contact-us" action="index.php?s=Kontakt" method="post">

	      <div class="formblock">
		<label class="screen-reader-text">Name</label>
		<input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName'];?>" class="txt requiredField <?php if($nameError != '') { echo inputError; } ?>" placeholder="Name:" />
		<?php if($nameError != '') { ?>
		  <span class="error"><?php echo $nameError;?></span> 
		<?php } ?>
	      </div>
                        
	      <div class="formblock">
		<label class="screen-reader-text">Email</label>
		<input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?>" class="txt requiredField email <?php if($emailError != '') { echo 'inputError'; } ?>" placeholder="Email:" />
		<?php if($emailError != '') { ?>
		  <span class="error"><?php echo $emailError;?></span>
		<?php } ?>
	      </div>
                        
	      <div class="formblock">
		<label class="screen-reader-text">Nachricht</label>
		<textarea name="comments" id="commentsText" class="txtarea requiredField <?php if($commentError != '') { echo 'inputError'; } ?>" placeholder="Message:"><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?></textarea>
		<?php if($commentError != '') { ?>
		  <span class="error"><?php echo $commentError;?></span> 
		<?php } ?>
	      </div>
                        
	      <div class="formblock">
		<label class="screen-reader-text">Captcha</label>							
		<img src="inc/captcha_form.php<?=$sessionstringnew;?>" alt="Captcha" id="P91Captcha" />
		<br /><a href="javascript:P91Captcha('<?=$sessionstringadd;?>');">Neuer Code?</a>
		<br /><br />
		<input type="text" name="code" id="code" class="text requiredField code <?php if($captchaError != '') { echo 'inputError'; } ?>" maxlength="50" placeholder="Captcha-Code" />
		<?php if($captchaError != '') { ?>
		  <span class="error"><?php echo $captchaError;?></span> 
		<?php } ?>
	      </div>

	      <div class="formblock">
	      <button name="submit" type="submit" class="subbutton">Absenden</button>
	      <input type="hidden" name="submitted" id="submitted" value="true" />
	      </div>

	    </form>			
	  </div>
				
	  <?php } ?>
	</div>
    </div><!-- End #contact -->
	
<script type="text/javascript">
	<!--//--><![CDATA[//><!--
	$(document).ready(function() {
		$('form#contact-us').submit(function() {
			$('form#contact-us .error').remove();
			var hasError = false;
			$('.requiredField').each(function() {
				if($.trim($(this).val()) == '') {
					var labelText = $(this).prev('label').text();
					$(this).parent().append('<span class="error">Sie haben '+labelText+' vergessen anzugeben.</span>');
					$(this).addClass('inputError');
					hasError = true;
				} else if($(this).hasClass('email')) {
					var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
					if(!emailReg.test($.trim($(this).val()))) {
						var labelText = $(this).prev('label').text();
						$(this).parent().append('<span class="error">Sorry! Die von Ihnen eingegebene '+labelText+' ist fehlerhaft.</span>');
						$(this).addClass('inputError');
						hasError = true;
					}
				} else {
					var codeReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
					if (sha1(trim(strip_tags(strtoupper($_POST['code'])))) != $_SESSION['P91Captcha_code']) {
						var labelText = $(this).prev('label').text();
						$(this).parent().append('<span class="error">Sorry! Das von Ihnen eingegebene '+labelText+' ist fehlerhaft.</span>');
						$(this).addClass('inputError');
						hasError = true;
					}
				}
			});
			if(!hasError) {
				var formInput = $(this).serialize();
				$.post($(this).attr('action'),formInput, function(data){
					$('form#contact-us').slideUp("fast", function() {				   
						$(this).before('<p class="tick"><strong>Danke!</strong> Ihre Nachricht an uns wurde zugestellt.</p>');
					captcha_});
				});
			}

			return false;	
		});
	});
	//-->!]]>
</script>

</article>
