$(document).ready(function(){
	
	// Calling our splashScreen plugin and
	// passing an array with images to be shown
	
	$('#promoIMG').splashScreen({
		textLayers : [
			'img/splash/intro_002.png',
//			'img/splash/intro_003.png',
			'img/splash/intro_005.png',
//			'img/splash/intro_004.png',
			'img/splash/intro_001.png'
		]
	});
	
});
