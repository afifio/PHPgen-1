<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta name="robots" content="index" />
  <meta name="robots" content="follow" />
  <meta name="robots" content="all" />
  <meta name="language" content="deutsch, de" />
  <meta name="keywords" content="Seitengenerator, Suchw&ouml;rter" />
  <meta name="description" content="Seitengenerator" />
  <meta name="autor" content="Maik Vattersen" />
  <meta name="publisher" content="eXigem Media GbR" />
  <meta name="distribution" content="global" />
  <meta name="page-topic" content="Seitengenerator" />
  <meta name="siteinfo" content="http://www.exigem.com/robots.txt" />
  <meta name="Revisit" content="After 7 days" />
