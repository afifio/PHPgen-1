var msg = new Array ();
msg[0] = "<p><i>Nicht auf Personen kommt es an, sondern auf Werke im Dienste der Gemeinschaft.</i><br><span class=\"sign\">Albert Einstein</span></p>";
msg[1] = "<p><i>Mit unseren Gedanken formen wir die Welt.</i><br><span class=\"sign\">Buddha</span></p>";
msg[2] = "<p><i>Wer zur Quelle will, muss gegen den Strom schwimmen.</i><br><span class=\"sign\">aus Japan</span></p>";
msg[3] = "<p><i>Nichts sollte festgehalten werden, was immer es auch sei.</i><br><span class=\"sign\">Buddha</span></p>";
msg[4] = "<p><i>Alles gro&szlig;e kommt aus innerer Stille.</i><br><span class=\"sign\">aus China</span></p>";
msg[5] = "<p><i>Wer offenen Sinnes ist, findet stets einen Grund zur Freude.</i><br><span class=\"sign\">Zen-Weisheit</span></p>";
msg[6] = "<p><i>Die Seeligkeit eines Augenblicks verl&auml;ngert das Leben um tausend Jahre.</i><br><span class=\"sign\">aus Japan</span></p>";
msg[7] = "<p><i>Wer die Mitte findet, siet das Ganze.</i><br><span class=\"sign\">aus China</span></p>";
msg[8] = "<p><i>Die Sch&ouml;nheit ist die Bl&uuml;te des Gl&uuml;cks.</i><br><span class=\"sign\">aus Japan</span></p>";
msg[9] = "<p><i>Klopf an den Himmel und horch auf den Klang.</i><br><span class=\"sign\">Zen-Weisheit</span></p>";
msg[10] = "<p><i>Sich das Wesen des Zarten bewahren zu können, hei&szlig;t stark sein.</i><br><span class=\"sign\">aus China</span></p>";
msg[11] = "<p><i>Nur wer selbst ruhig bleibt, kann zur Ruhest&auml;tte all dessen werden, was Ruhe sucht.</i><br><span class=\"sign\">Lao Tse</span></p>";
msg[12] = "<p><i>Dem sind keine Grenzen gesetzt, der sie nicht hinnimmt.</i><br><span class=\"sign\">Zen-Weisheit</span></p>";
msg[13] = "<p><i>Das Sch&ouml;nste ist die Harmonie.</i><br><span class=\"sign\">aus China</span></p>";
msg[14] = "<p><i>Was du genie&szlig;t von Tag zu Tag, das ist dein Reichtum.</i><br><span class=\"sign\">aus Indien</span></p>";
msg[15] = "<p><i>Suche die kleinen Dinge, die dem leben Freude geben.</i><br><span class=\"sign\">Konfuzius</span></p>";
msg[16] = "<p><i>Der Zauber des Augenblicks liegt in der Magie des Allt&auml;glichen.</i><br><span class=\"sign\">aus Indien</span></p>";
msg[17] = "<p><i>Was du leibst, lass frei. Kommt es zur&uuml;ck, geh&ouml;rt es dir - f&uuml;r immer.</i><br><span class=\"sign\">Konfuzius</span></p>";
msg[18] = "<p><i>Am ruhigen Fluss ist das Ufer voller Blumen.</i><br><span class=\"sign\">aus China</span></p>";
msg[19] = "<p><i>Der Wind beugt die Gr&auml;ser, aber er bricht sie nicht.</i><br><span class=\"sign\">aus China</span></p>";
msg[20] = "<p><i>Das Dinge streben nach dem Licht, und die str&ouml;mende Kraft gibt ihnen Harmonie.</i><br><span class=\"sign\">Lao Tse</span></p>";
msg[21] = "<p><i>Wenn die Wurzeln tief sind, braucht man den Wind nicht zu f&uuml;rchten.</i><br><span class=\"sign\">aus China</span></p>";
msg[22] = "<p><i>Die Welt ist voll von kleinen Freuden, die Kunst besteht nur darin, sie zu sehen, ein Auge dafür zu haben.</i><br><span class=\"sign\">Li-Tai-Phe</span></p>";
msg[23] = "<p><i>Wahrheit ist die Quelle des Mutes.</i><br><span class=\"sign\">aus China</span></p>";
msg[24] = "<p><i>Jedes Wasser hat seine Quelle, jeder Baum seine Wurzel.</i><br><span class=\"sign\">aus China</span></p>";
msg[25] = "<p><i>Der Himmel schenkt uns Gaben - Lasst sie uns n&uuml;tzen!</i><br><span class=\"sign\">Li T&rsquo;ai Po</span></p>";
msg[26] = "<p><i>Halte ein, wenn es Zeit ist innezuhalten! Handle, wenn es Zeit ist zu handeln.</i><br><span class=\"sign\">I Ging</span></p>";
msg[27] = "<p><i>Das Leben ist hier und jetzt.</i><br><span class=\"sign\">Buddha</span></p>";
msg[28] = "<p><i>Eine Morgenstunde ist mehr wert als zwei Abendstunden.</i><br><span class=\"sign\">aus China</span></p>";
msg[29] = "<p><i>Wer sich selbst viel zutraut, wird andere &uuml;bertreffen.</i><br><span class=\"sign\">aus China</span></p>";
msg[30] = "<p><i>Einen Tag lang ungest&ouml;rt in Mu&szlig;e zu verleben, hei&szlig;t einen Tag lang ein Unsterblicher zu sein.</i><br><span class=\"sign\">aus China</span></p>";
msg[31] = "<p><i>Jeder nimmt die Farbe seiner Umwelt an.</i><br><span class=\"sign\">aus China</span></p>";
var i = Math.floor(7*Math.random())

function zufallsspruch() {
document.write(msg[i]);
}
