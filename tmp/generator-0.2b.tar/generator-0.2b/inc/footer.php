<?php
  echo "\n",'<footer>',"\n";
  echo "·:::· ";
  if(SITE_LOADTIME == "1") echo "Seiten-Ladezeit: <span id=\"Ladezeit\"><b class=\"warn\">no js</b></span> Sek. ·:::· ";
  echo "&copy; <!--#config timefmt=\"%Y\" --><!--#echo var=\"LAST_MODIFIED\" --> <a href=\"index.php?s=", SITE_DEFAULT ,"\">", SITE_NAME ,"</a> ·:::·";
  echo '    <div id="hoster">
      <a href="http://www.exigem.com/" title="hosted by exigem"></a>
    </div>';
  echo "\n",'</footer>',"\n";
?>
