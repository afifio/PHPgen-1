  <header>
    <div id="headnav"> 
      <ul>
	<?php 

	if (!isset($_SESSION['angemeldet']) || !$_SESSION['angemeldet']) {
	  echo "<li><a href=\"admin/login.php\">Login</a></li>
		";
	} else {
          echo "<li><a href=\"admin/logout.php\">Logout</a></li>";

	}; ?>             

        <li><a href="index.php?s=<?php echo SITE_IMPRINT ?>">§</a></li>
        <li><a href="http://feeds.feedburner.com/exigem" target="_blank" rel="external">RSS</a></li>
        <li><a href="http://feeds.feedburner.com/exigem" target="_blank" rel="external">Atom</a></li>

	<?php 
	if (!isset($_SESSION['angemeldet']) || !$_SESSION['angemeldet']) {
          echo "<li><a href=\"admin\">Admin</a></li>";
	} else {
	  echo "<li><a href=\"admin\">Admin</a></li>";

	}; ?> 

        <li><a href=\"\">Register</a></li>

      </ul>
    </div>

    <h1><?php echo SITE_NAME ?></h1>
    <h2><?php echo SITE_TITLE ?></h2>
  </header>
