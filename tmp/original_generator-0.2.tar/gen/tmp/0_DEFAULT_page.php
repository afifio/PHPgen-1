<article>

<header>
  <time datetime="2011-04-13" pubdate>DATUM</time>
  <h1>UEBERSCHRIFT</h1>
</header>

  <p>TEXT</p>

</article>
