<?php

if($_POST['Submit'])
{
$company = $_POST['company'];
$address1 = $_POST['address1'];
$address2 = $_POST['address2'];
$address3 = $_POST['address3'];
$address4 = $_POST['address4'];
$contact = $_POST['contact'];
$contact2 = $_POST['contact2'];
$phone = $_POST['phone'];

//the data
$data = "$company | $address1 | $address2 | $address3 | $address4 | $contact | $contact2 | $phone\n
";

//open the file and choose the mode
$fh = fopen("../pages/kunden.txt", "a");
fwrite($fh, $data);

//close the file
fclose($fh);

print "Information Submitted. Thanks";
}
else
{
print <<<ENDOFTXT
</style><form name="form1" method="post" action="test.php">
<table width="780" border="0" align="center">
<tr>
<td width="256"><span class="style5">Company Name:</span></td>
<td width="514"><input name="company" type="text" id="company"></td>
</tr>

<tr>
<td><span class="style5">Address
:</span></td>
<td><input name="address1" type="text" id="address1" value=""></td>
</tr>
<tr>
<td><span class="style5">Unit / Apt :</span></td>
<td><input name="address2" type="text" id="address2"></td>
</tr>
<tr>
<td><span class="style5">City, Pr : </span></td>
<td><input name="address3" type="text" id="address3"></td>
</tr>
<tr>
<td><span class="style5">Postal Code :</span></td>
<td><input name="address4" type="text" id="address4"></td>
</tr>
<tr>
<td><span class="style5">Contact Name: </span></td>
<td><input name="contact" type="text" id="contact" value="First Name Last Name"></td>
</tr>
<tr>
<td><span class="style5">Email: </span></td>
<td><input name="contact2" type="text" id="contact2"></td>
</tr>
<tr>
<td><span class="style5">Phone :</span></td>
<td><input name="phone" type="text" id="phone" value="( ) ">
<input name="Submit" type="submit" class="style5" value="Submit"></td>
</tr>
<tr>
<td colspan="2"><div align="center"></div></td>
</tr>
</table>
<p align="center">&nbsp;</p>
</form>
ENDOFTXT;
}

?> 
