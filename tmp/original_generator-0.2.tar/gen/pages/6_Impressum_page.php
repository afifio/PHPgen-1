<article>

<header>

  <time datetime="2011-04-14" pubdate>14.April 2011</time>

  <h1>Impressum Seite</h1>

</header>

<p>﻿﻿﻿﻿﻿﻿﻿eXigem Media GbR</p>

<p>Besuchen Sie uns auf unserer offiziellen Webseite unter <a href="http://www.exigem.com/">www.exigem.com</a>.</p>

<p>Sollten Sie Fragen oder Anregungen haben, verwenden Sie Bitte das Kontakt-Formular der Webseite (<a href="http://www.exigem.com/#kontakt">http://exigem.com/#kontakt</a>).</p>

<hr />

<p>Haftungsausschluss für Links von unserer Seite:</p>

<p>Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links. Für den Inhalt der verlinkten Seiten sind ausschließlich deren Betreiber verantwortlich. Rechtswidrige Inhalte waren zum Zeitpunkt der Verlinkung nicht erkennbar und werden vor dem Verlinken sorgfältig von uns geprüft. Eine permanente inhaltliche Kontrolle aller verlinkten Seiten ist jedoch ohne konkrete Anhaltspunkte einer Rechtsverletzung nicht zumutbar. Bei bekannt werden von Rechtsverletzungen werden wir derartige Links umgehend entfernen.</p>

<p>Sollten Sie einen Solchen Fall melden wollen verwenden Sie Bitte das Kontakt-Formular von unserer Webseite (<a href="http://www.exigem.com/#kontakt">http://exigem.com/#kontakt</a>).
</p>
  
</article>
