<article>
      <header>
        <time datetime="2011-04-13" pubdate>13.April 2011</time>
        <h1>Generator-Screenshots</h1>
      </header>

      <p>
	<a href="img/screenshots/generator_fontend.png">
		<img src="img/screenshots/generator_fontend.png" height="231" width="320" alt="Generator 0.1 main screenshot" />
	</a>
	Version 0.1 Main Frontendansicht
      </p>

      <p>
	<a href="img/screenshots/generator_backend.png">
		<img src="img/screenshots/generator_backend.png" height="231" width="320" alt="Generator 0.1 main screenshot" />
	</a>
	Version 0.1 Main Backendansicht
      </p>

</article>

