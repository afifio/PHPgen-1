<?php 

// Konfigurationsdatei 
// 
// 

// Seitendaten
define ("BASE", "http://www.exigem.com/gen"); 		// Basisurl, so brauchen wir nur hier immer ändern
define ("MAIL", "kontakt&#64;exigem&#46;com"); 		// Ihre Mailadresse

define ("SITE_NAME", "eXigem Media");			// Der Name der Seite
define ("SITE_TITLE", "Wir lieben gutes Webdesign");	// Untertitel oder Slogan

// SICHERHEIT
define ("SITE_OWNER", "admin");				// Der verwendete Benutzername
define ("SITE_PASSWD", "nimda");			// Das verwendete Passwort

// Social
define ("TWITTER", "http://twitter.com/#%21/exigem"); 	// Twitterurl
define ("FACEBOOK", "http://www.facebook.com/pages/Exigem-Media-GbR/133882766677923"); // Facebookurl

// Wird im Mailfooter verwendet
define ("COMPANY_NAME", "eXigem Media");		// Name
define ("COMPANY_PHONE", "0531 428 77 630");		// Rufnummer
define ("COMPANY_FAX", "0531 428 77 639");		// Faxnummer

// Optionales
define ("SITE_INTRO", "1");				// 1 = Bei erstem Seitenaufruf Intro anzeigen
define ("SITE_LOADTIME", "1");				// 1 = Anzeige der Seitenladezeit im Footer 
define ("SITE_VALIDATOR_HTML", "1");			// 1 = Anzeige des w3c HTML Validators im Footer 
define ("SITE_VALIDATOR_CSS", "0");			// 1 = Anzeige des w3c CSS Validators im Footer 

define ("SITE_DEFAULT", "Home"); 			// Standartseite die geladen wird
define ("SITE_IMPRINT", "Impressum");			// Impressum 

define ("DEBUG", "0"); 					// 0: Kein Output 
                       					// 1: Wenig Output  
                       					// 2: Alle Fehler anzeigen

define ("VERSION","0.3.1");				// Versionshinweis

?>
