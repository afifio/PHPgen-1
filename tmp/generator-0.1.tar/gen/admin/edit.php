<?php include('auth.php'); ?>
<?php

$action=$_POST['action'];
$textarea=$_POST['textarea'];
$url=$_REQUEST['s'];
$i = 0;

include ("../config.php");
// load functions

include ("inc/func_html.php");
include ("inc/func_pages.php");
// start script
include ("inc/func_init.php");

$ready_url = 'edit.php?s='.$s ;
$return="index.php?s=$s";

if($_GET['p']){
$page=$_GET['p'];
}

// Assume your text pages are called right Regex

if (file_exists($url)) {
// do nothing
} else {
$i = home_pages($s);
$url = "../pages/" . $i . "_" . $s  . "_page.php";
}

// Get page
$data = implode("", file($url)); 

$ta=br2nl($data);

function br2nl($str) {
return preg_replace('=<br */? >=i', "<br />", $str);
}

if($action=="save"){
$newtext=stripslashes($textarea);
//$newtext = str_replace("<?", "", $newtext);
//$newtext = str_replace("? >", "", $newtext);
//$newtext = nl2br($newtext);
$fh = fopen($url, 'w') or die("can't open file <b>$url</b>");
fwrite($fh, $newtext);
fclose($fh); 
//echo "var s : ", $s ,"<br />";
//echo "var action : ", $action ,"<br />";
//echo "var n : ", $n ,"<br />";
//echo "var url : ", $url ,"<br />";
//echo "var page : ", $page ,"<br />";
//echo "var ready_url : ", $ready_url ," *<br />";
//echo "var return : ", $return ,"<br />";
//header ("Location: $return");
//header('Location: index.php?s='.$ready_url.'');
echo '<meta http-equiv="refresh" content="1; url='.$ready_url.'" />';
}
else{

// head
home_html_start();
home_html_head();

// Sidebar
home_html_sidebar_start();
home_html_menu($s);
echo "\n",'  <div id="admin-subnav">',"\n";
echo '  <nav>
    <ul id="adminnav">
      <li><h3>Seiten</h3></li>
      <li><a href="create.php?s='. $s .'">Erstellen</a></li>
      <li class="menu-active"><a href="edit.php?s='. $s .'">Editieren</a></li> 
      <li><a href="">Kopieren</a></li>
      <li><a href="">Verschieben</a></li> 
      <li><a href="">L&ouml;schen</a></li>
    </ul>
</nav>
</div>
<div id="admin-subnav2">
  <nav>
    <ul id="adminnav2">
      <li><h3>Dateien</h3></li>
      <li><a href="">Upload</a></li>
      <li><a href="">Edit</a></li> 
      <li><a href="">Delete</a></li>
    </ul>
</nav>';
echo "\n",'  </div>',"\n\n";

home_html_sidebar_stop();

// body & wrap
echo "\n",'  <div id="content">',"\n";

echo"
<article>

      <header>
        <time datetime=\"2011-04-14\" pubdate>14.April 2011</time>
        <h1>Seite ". $s . " editieren</h1>
      </header>

<p>Make Changes and click \"Save Changes\" at the very bottom ...</p>
<form action='edit.php?s=$s' method='post'>
<input type='hidden' name='action' value='save'>
<input type='hidden' name='p' value='$url'>
<input type='hidden' name='n' value='$n'>
<textarea name='textarea' rows='25' cols='100'>$ta</textarea>
<br /><br />
<input type='submit' name='submit' value='Save Changes'> <a href=\"$return\"><button>zur&uuml;ck</button></a>
</form>

<div id=\"debug_out\">
<p>Variable s : " . $s . "</p>
<p>Variable page : " . $page . "</p>
<p>Variable url : " . $url . "</p>
<p>Variable n : " . $n . "</p>
<p>Variable i : " . $i . "</p>
<p>Variable str : " . $str . "</p>
<p>Variable return : " . $return . "</p>
<p>Variable ready_url : " . $ready_url . "</p>
</div>

</article>

";

echo "\n",'  <div id="clear">&nbsp;</div>',"\n";
echo "\n",'  </div>',"\n\n";

// foot
home_html_foot();

// close body & wrap

home_html_stop();
}

// where to go back to after the edit ...


?> 
