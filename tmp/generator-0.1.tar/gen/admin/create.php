<?php include('auth.php'); ?>
<?php

include ("../config.php");
// load functions

include ("inc/func_html.php");
include ("inc/func_pages.php");
// start script
include ("inc/func_init.php");

if($_GET['p']){
$page=$_GET['p'];
}

if (file_exists($input_url)) {
// do nothing
echo "file exist";
} else {

echo $url ;

$i = home_pages($s);
$i = $i++;
$url = "../pages/" . $i . "_" . $input_url  . "_page.php";
}

// Get page

if($action=="save"){
$newtext=stripslashes($textarea);
$newurl=stripslashes($input);
$ourFileName = $newurl ;
$ourFileHandle = fopen($ourFileName, 'w') or die("can't open file");
fclose($ourFileHandle);
echo "var s : ", $s ,"<br />";
echo $ourFileName;
//echo '<meta http-equiv="refresh" content="1; url='.$ready_url.'" />';
} else {

// head
home_html_start();
home_html_head();

// Sidebar
home_html_sidebar_start();
home_html_menu($s);
echo '
  <div id="admin-subnav">
    <nav>
      <ul id="adminnav">
        <li><h3>Seiten</h3></li>
        <li><a href="create.php?s='. $s .'">Erstellen</a></li>
        <li class="menu-active"><a href="edit.php?s='. $s .'">Editieren</a></li> 
        <li><a href="">Kopieren</a></li>
        <li><a href="">Verschieben</a></li> 
        <li><a href="">L&ouml;schen</a></li>
      </ul>
    </nav>
  </div>
  <div id="admin-subnav2">
    <nav>
      <ul id="adminnav2">
        <li><h3>Dateien</h3></li>
        <li><a href="">Upload</a></li>
        <li><a href="">Edit</a></li> 
        <li><a href="">Delete</a></li>
      </ul>
    </nav>
  </div>';
echo "\n",'',"\n\n";

home_html_sidebar_stop();

// body & wrap
echo "\n",'  <div id="content">',"\n";

echo"
<article>

      <header>
        <time datetime=\"2011-04-14\" pubdate>14.April 2011</time>
        <h1>Seite erstellen</h1>
      </header>

<p>Make Changes and click \"Save Changes\" at the very bottom ...</p>

<form action='create.php' method='post'>
<input type='hidden' name='action' value='save'>
<input type='hidden' name='p' value='$input_url'>
<input type='hidden' name='n' value='$n'>

<input type=\"text\">$tu</input>

<textarea name='textarea' rows='10' cols='100'>$ta</textarea>

<br /><br />
<input type='submit' name='submit' value='Save Changes'> <a href=\"index.php\"><button>zur&uuml;ck</button></a>
</form>

<div id=\"debug_out\">
<p>Variable s : " . $s . "</p>
<p>Variable page : " . $page . "</p>
<p>Variable url : " . $url . "</p>
<p>Variable n : " . $n . "</p>
<p>Variable i : " . $i . "</p>
<p>Variable str : " . $str . "</p>
<p>Variable return : " . $return . "</p>
<p>Variable ready_url : " . $input_url . "</p>
</div>

</article>

";

echo "\n",'  <div id="clear">&nbsp;</div>',"\n";
echo "\n",'  </div>',"\n\n";

// foot
home_html_foot();

// close body & wrap

home_html_stop();
}

?> 
