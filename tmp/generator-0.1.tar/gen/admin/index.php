<?php include('auth.php'); ?>
<?php
// Generator Main Page

// load config
include ("../config.php");
// load functions

include ("inc/func_html.php");
include ("inc/func_pages.php");
// start script
include ("../inc/func_init.php");

// head
home_html_start();
home_html_head();

// Sidebar
home_html_sidebar_start();
home_html_menu($s);
echo "\n",'  <div id="admin-subnav">',"\n";
echo '  <nav>
    <ul id="adminnav">
      <li><h3>Seiten</h3></li>
      <li><a href="create.php?s='. $s .'">Erstellen</a></li>
      <li><a href="edit.php?s='. $s .'">Editieren</a></li> 
      <li><a href="">Kopieren</a></li>
      <li><a href="">Verschieben</a></li> 
      <li><a href="">L&ouml;schen</a></li>
    </ul>
</nav>
</div>
<div id="admin-subnav2">
  <nav>
    <ul id="adminnav2">
      <li><h3>Dateien</h3></li>
      <li><a href="">Upload</a></li>
      <li><a href="">Edit</a></li> 
      <li><a href="">Delete</a></li>
    </ul>
</nav>';
echo "\n",'  </div>',"\n\n";
home_html_sidebar_stop();

// body & wrap
echo "\n",'  <div id="content">',"\n";
//echo home_pages_load($s);
echo admin_pages_load($s);

echo "\n",'  <div id="clear">&nbsp;</div>',"\n";
echo "\n",'  </div>',"\n\n";

// foot
home_html_foot();

// close body & wrap

home_html_stop();

?>
