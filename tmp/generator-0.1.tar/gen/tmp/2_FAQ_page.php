<article>

      <header>
        <time datetime="13.04.2011" pubdate>13.April 2011</time>
        <h1>Generator-FAQ</h1>
      </header>


<ul>
	<li><b>Was ist der Generator?</b> - Generator is an image file index for your webspace. It creates some cached thumpnail images and returns a html page. </li>
	<li><b>What is the main goal for this project?</b> - Having an easy way to make many picures accessible for your www-browser.</li>
	<li><b>What license is used for Generator?</b> - Generator is published under the terms of the GNU general public licence.</li>
	<li><b>Can I support Generator?</b> - Yes you can!
		<ul>
			<li>Write some code in php. (multilanguage support, improve ajax features, etc...)</li>
			<li>Create a new theme with css.</li>
			<li>Donate the project.</li>
		</ul>
	</li>
	<li><b>I have problems, can somebody help me?</b> - Yes, write an english or german email to the main developer at vaddi&#64;exigem.de.</li>
	<li></li>
	<li></li>
</ul>

</article>
