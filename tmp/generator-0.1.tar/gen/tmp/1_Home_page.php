<article>
<header>
  <time datetime="2011-04-13" pubdate>13.April 2011</time>
  <h1>Willkommen bei dem Webseitengenerator</h1>
</header>

<div id="mainsite_subhead">
  <!-- Slideshow  --> 
  <div class="slideshow" id="HomeTicker">
    <a href="#" title="Link zu Leistungen"> 
      <img src="img/slideshow/001.png" alt="" />
      <span class="more">» Über uns</span>
      <span class="desc">
      <strong>Über Uns</strong>
      Besuchen Sie unsere Seite mit mehr Informationen.
      </span>
    </a>

    <a href="#" title="Link zu Lackpflege">
      <img src="img/slideshow/001.png" alt="" />
      <span class="more">» Lackpflege</span>
      <span class="desc">
      <strong>Professionelle Lackpflege</strong>
      Bei der Lackpflege und Aufbereitung gehen wir auf Ihre Vorstellungen und Wünsche ein und beraten Sie Gerne.
      </span>
    </a>
  </div>

  <!-- News  --> 
  <div id="news">
    <a href="#">News 01Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. ut labore et dolore magna aliquyam erat,sed diam voluptua.</a>
    <a href="#">News 02Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. ut labore et dolore magna aliquyam erat,sed diam voluptua.</a>
    <a href="#">News 03Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. ut labore et dolore magna aliquyam erat,sed diam voluptua.</a>
  </div>

</div>
<div class="clear"></div>
</article>
<article>
<header>
  <time datetime="2011-04-13" pubdate>13.April 2011</time>
  <h1>Neuigkeiten</h1>
</header>

<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>

<ul>
	<li></li>
</ul>

</article>
<article>
<header>
  <time datetime="2011-04-13" pubdate>13.April 2011</time>
  <h1>Andere Neuigkeiten</h1>
</header>

<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>

<ul>
	<li></li>
</ul>

</article>
