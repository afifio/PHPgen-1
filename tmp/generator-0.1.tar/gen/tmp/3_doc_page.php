<article>

      <header>
        <time datetime="2011-04-13" pubdate>13.April 2011</time>
        <h1>Generator-Documentation</h1>
      </header>


<p><i>from the README file:</i></p>
<pre>
requirements
- php
- webspace where the webserver can write into the file system
- some simple html files ;)

installation
- uncompress generator-*.tar in your html public directory "/var/www/" for example. 
- rename the uncompressed directory "generator" to your favorite output directory 
  eg. webserver, server, web whatever you want.
- make that directory rwiteable for the webservers user - generator creates all other
  needed directorys by itself
- configure Generator by editing the config file config.php
- copy your simple HTML-Files into the Generator-pages directory 
- check your installation by browsing your chossen directoy by your webserver
  and if your config works -> READY!

</pre>
</article>
