<?php
// Homepage 0.1 Configuration File

define ("VERSION","0.1");

define ("SITE_NAME", "Homepage Generator");
define ("SITE_TITLE", "Home of Homepage Generator");
define ("SITE_OWNER", "eXigem Media");
define ("SITE_COPYRIGHT", "&copy; <!--#config timefmt=\"%Y\" --><!--#echo var=\"LAST_MODIFIED\" --> <a href=\"http://www.exigem.com/\" target=\"_blank\">eXigem Media GbR</a>");

define ("SITE_LOADTIME", "1");	// 1 = Anzeige der Seitenladezeit im Footer 
define ("SITE_DEFAULT", "Home");

define ("DEBUG", "0"); // 0: no output, 
                       // 1: some output  
                       // 2: heavy output

?>
