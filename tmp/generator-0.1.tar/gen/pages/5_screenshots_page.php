<article>
      <header>
        <time datetime="2011-04-13" pubdate>13.April 2011</time>
        <h1>Generator-Screenshots</h1>
      </header>

      <p>
	<a href="img/0.1-main.jpg">
		<img src="img/0.1-main.jpg" height="248" width="320" alt="Generator 0.1 main screenshot" />
	</a>
	Version 0.1 Main
      </p>
</article>

