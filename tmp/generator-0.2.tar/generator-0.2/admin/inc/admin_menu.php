<?php echo '
<div id="admin-subnav">
  <nav>
    <ul id="adminnav">
      <li class="menufirst"><h3>Seiten</h3></li>
      <li><a href="create.php">Erstellen <img src="../img/icons/add.png" alt="+" /> </a></li>
      <li><a href="edit.php?s='. $s .'">Bearbeiten <img src="../img/icons/right.png" alt="&#9997;" /> </a></li> 
      <li><a href="remove.php?s='. $s .'">L&ouml;schen <img src="../img/icons/remove.png" alt="&#10007;" /> </a></li>
    </ul>
  </nav>
</div>
<div id="admin-subnav2">
  <nav>
    <ul id="adminnav2">
      <li><h3>Dateien</h3></li>
      <li><a href="">Upload <img src="../img/icons/up.png" alt="&uparr;" /> </a></li>
      <li><a href="">Bearbeiten <img src="../img/icons/right.png" alt="&#9997;" /> </a></li> 
      <li><a href="">L&ouml;schen <img src="../img/icons/remove.png" alt="&#10007;" /> </a></li>
    </ul>
  </nav>
</div>'; ?>
