<article>

<header>
  <time datetime="2011-04-13" pubdate>13.April 2011</time>
  <h1>Willkommen bei dem Webseitengenerator</h1>
</header>

<div id="mainsite_subhead">
  <!-- Slideshow  --> 
  <div class="slideshow" id="HomeTicker">
    <a href="#" title="Link zu Leistungen"> 
      <img src="img/slideshow/001.png" alt="" />
      <span class="more">» Über uns</span>
      <span class="desc">
      <strong>Über Uns</strong>
      Besuchen Sie unsere Seite mit mehr Informationen.
      </span>
    </a>

    <a href="#" title="Link zu Lackpflege">
      <img src="img/slideshow/001.png" alt="" />
      <span class="more">» Lackpflege</span>
      <span class="desc">
      <strong>Professionelles Editieren</strong>
      <p>Ich teste das Editieren. Funktioniert super</p>
      </span>
    </a>
  </div>

  <!-- News  --> 
  <div id="news">
    <a href="#">News 01<br /> Die erste Version ist in Arbeit. Das Admin Backend ist im Bau.</a>
    <a href="#">News 02<br /> Unterkategorien im Admin Backand angelegt. Links zum editieren, erstellen, kopieren, verschieben und löschen.</a>
    <a href="#">News 03<br /> Das Admin Backend ist angefangen und die Haupt Linkführung wurde eingebaut. </a>
  </div>

</div>
<div class="clear"></div>
</article>
<article>
<header>
  <time datetime="2011-04-13" pubdate>13.April 2011</time>
  <h1>Was ist der Generator?</h1>
</header>

<p>Der Webseiten Generator erstellt aus einfachen Textdateien Webseiten. Er erstellt automatisch Menu einträge (zur Zeit leider noch ohne Unterkategorien), Kopfbereich und Fußzeile. Sie brauchen nur noch ihre CSS-Datei anzupassen um aus dem Standartthema ein eigenes Theme zu erstellen. Die Inhalte können Sie direkt auf der Adminseite editieren. Der Adminbereich ist Passwort gesichert, verwendet jedoch keine Benutzerrollen Verwaltung.</p>


</article>
<article>
<header>
  <time datetime="2011-04-13" pubdate>13.April 2011</time>
  <h1>Wer sollte den Generator verwenden? </h1>
</header>

<p>Der Webseiten Generator ist in erster Linie für Menschen gedacht, die eine Webseite benötigen aber keine Zeit oder Muse haben um sich mit den notwendigen Kodierungs Wirrwarr vertraut zu machen. Daher kann man hier einfachsten HTML-Code vorgeben und braucht sich um die vielen Extras keine Gedanken zu machen</p>

</article>
