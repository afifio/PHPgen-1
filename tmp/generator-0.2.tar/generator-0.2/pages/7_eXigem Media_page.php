<article>

<header>
  <time datetime="2011-04-13" pubdate>DATUM</time>
  <h1>Hallo, wir sind eXigem</h1>
</header>

  <p>Wir begründeten uns im Frühjahr 2010 mit einer einfachen Idee - Die Erstellung unglaublicher Webseiten! Heute arbeiten wir mit Communities, Blog-Sytemen sowie auch mit Statischen und Dynamischen Webseiten.
Wir sind der richtige Partner, wenn es um Webseiten geht, die das spezielle Etwas haben sollen. Erfahren Sie Mehr über uns.
</p>

</article>
